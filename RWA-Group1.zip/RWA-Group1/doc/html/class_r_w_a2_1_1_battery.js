var class_r_w_a2_1_1_battery =
[
    [ "Battery", "class_r_w_a2_1_1_battery.html#a002b29ccfabb177ef8632b1b25c2a5e1", null ],
    [ "~Battery", "class_r_w_a2_1_1_battery.html#a2f91acd95ea37a551dde427ef9021a80", null ],
    [ "discharge", "class_r_w_a2_1_1_battery.html#ad2ca74c95d5a8766eb250b9057dd2667", null ],
    [ "get_current_charge", "class_r_w_a2_1_1_battery.html#a8c7b14e505f2e98fc6b1379bd3e1a9bb", null ],
    [ "start_charging", "class_r_w_a2_1_1_battery.html#a65c31a8b2f786fa04c52383db001492a", null ]
];