var searchData=
[
  ['get_5fcurrent_5fcharge_75',['get_current_charge',['../class_r_w_a2_1_1_battery.html#a8c7b14e505f2e98fc6b1379bd3e1a9bb',1,'RWA2::Battery']]],
  ['get_5fsensor_5fvalues_76',['get_sensor_Values',['../class_r_w_a2_1_1_mobile_robot.html#a1b64548d12002a74332aebc287b4f0c5',1,'RWA2::MobileRobot']]]
];
