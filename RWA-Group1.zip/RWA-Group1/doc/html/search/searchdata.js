var indexSectionsWithContent =
{
  0: "abdglmoprsw~",
  1: "ablmsw",
  2: "r",
  3: "ablmsw",
  4: "abdglmprsw~",
  5: "bmops"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

