var searchData=
[
  ['read_5fdata_83',['read_data',['../class_r_w_a2_1_1_sensor.html#acdfc615eb39e41ee210405b222e616cd',1,'RWA2::Sensor']]],
  ['rotate_84',['rotate',['../class_r_w_a2_1_1_aerial_robot.html#a9d2c904ef3bf65919f578c4285beeec0',1,'RWA2::AerialRobot::rotate()'],['../class_r_w_a2_1_1_aquatic_robot.html#ac56dcbb47a79db60b9c8f29226da21da',1,'RWA2::AquaticRobot::rotate()'],['../class_r_w_a2_1_1_legged_robot.html#a709bec4704eed105c66ec1ff2b5235c0',1,'RWA2::LeggedRobot::rotate()'],['../class_r_w_a2_1_1_mobile_robot.html#ac3137f5b21c73796c10ebaffe2edf8d6',1,'RWA2::MobileRobot::rotate()'],['../class_r_w_a2_1_1_wheeled_robot.html#ab9895ff8360af2a281471afda2b5362d',1,'RWA2::WheeledRobot::rotate()']]]
];
