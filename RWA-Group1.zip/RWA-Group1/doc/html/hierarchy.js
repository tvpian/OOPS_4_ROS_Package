var hierarchy =
[
    [ "RWA2::Battery", "class_r_w_a2_1_1_battery.html", null ],
    [ "RWA2::MobileRobot", "class_r_w_a2_1_1_mobile_robot.html", [
      [ "RWA2::AerialRobot", "class_r_w_a2_1_1_aerial_robot.html", null ],
      [ "RWA2::AquaticRobot", "class_r_w_a2_1_1_aquatic_robot.html", null ],
      [ "RWA2::LeggedRobot", "class_r_w_a2_1_1_legged_robot.html", null ],
      [ "RWA2::WheeledRobot", "class_r_w_a2_1_1_wheeled_robot.html", null ]
    ] ],
    [ "RWA2::Sensor", "class_r_w_a2_1_1_sensor.html", null ]
];