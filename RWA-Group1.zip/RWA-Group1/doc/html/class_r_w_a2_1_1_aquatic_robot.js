var class_r_w_a2_1_1_aquatic_robot =
[
    [ "AquaticRobot", "class_r_w_a2_1_1_aquatic_robot.html#a709f78bf917c2c9ac07554ab655bc811", null ],
    [ "~AquaticRobot", "class_r_w_a2_1_1_aquatic_robot.html#a224c576fcbaa39305e42c95918f0da35", null ],
    [ "move", "class_r_w_a2_1_1_aquatic_robot.html#a1bb8749d0604799f1b6095bb69530673", null ],
    [ "print_Status", "class_r_w_a2_1_1_aquatic_robot.html#ad3d6aa246c173728ca44ff8c266a3104", null ],
    [ "rotate", "class_r_w_a2_1_1_aquatic_robot.html#ac56dcbb47a79db60b9c8f29226da21da", null ]
];