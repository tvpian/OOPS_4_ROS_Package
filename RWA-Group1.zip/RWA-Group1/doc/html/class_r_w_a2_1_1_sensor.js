var class_r_w_a2_1_1_sensor =
[
    [ "Sensor", "class_r_w_a2_1_1_sensor.html#af679dbe93e9a5294264129311aa134c0", null ],
    [ "~Sensor", "class_r_w_a2_1_1_sensor.html#a6701b7c5f824610ae3d9b5a3cc0b45a8", null ],
    [ "read_data", "class_r_w_a2_1_1_sensor.html#acdfc615eb39e41ee210405b222e616cd", null ]
];